document.querySelector(".open").addEventListener("click", () => {
    document.querySelector(".options").style.display = "flex"
})
document.querySelector(".nav-open").addEventListener("click", () => {
    document.querySelector(".options").style.display = "none"
})